# SHIBL — Demo Trading App

واجهة عربية للهاتف + خادم Flask تجريبي.

## التشغيل محلياً

1. ثبّت Python 3.10 أو أحدث.
2. افتح الطرفية داخل مجلد المشروع.
3. نفّذ:

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

Linux / macOS:
```bash
source .venv/bin/activate
```

ثم:

```bash
pip install -r requirements.txt
python app.py
```

افتح `http://127.0.0.1:8000`.

## واجهات API

- `GET /health`
- `GET /api/status`
- `POST /api/analyze`
- `POST /api/demo/order`
- `GET /api/demo/trades`

## مهم

هذه النسخة تجريبية فقط. لا تحتوي على تكامل Quotex ولا تنفذ صفقات حقيقية.
الرصيد والصفقات محفوظة في الذاكرة فقط وتُصفّر عند إعادة تشغيل الخادم.
بيانات الأسعار الافتراضية اصطناعية للاختبار وليست أسعار سوق مباشرة.
قبل نشرها للعامة يلزم إضافة قاعدة بيانات، مصادقة، حماية للطلبات، وإدارة أسرار.
