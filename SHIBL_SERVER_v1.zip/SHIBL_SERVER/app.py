from __future__ import annotations

import math
import os
import secrets
from datetime import datetime, timezone
from threading import Lock
from typing import Any

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False

# Demo-only in-memory state. It resets when the server restarts.
STATE_LOCK = Lock()
ACCOUNT = {"balance": 1000.0, "starting_balance": 1000.0}
TRADES: list[dict[str, Any]] = []
MAX_TRADE_AMOUNT = 100.0


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def as_number(value: Any) -> float | None:
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except (TypeError, ValueError):
        return None


def ema(values: list[float], period: int) -> list[float]:
    alpha = 2 / (period + 1)
    result = [values[0]]
    for value in values[1:]:
        result.append(alpha * value + (1 - alpha) * result[-1])
    return result


def rsi(values: list[float], period: int = 14) -> float:
    changes = [values[i] - values[i - 1] for i in range(1, len(values))]
    recent = changes[-period:]
    gains = sum(x for x in recent if x > 0) / period
    losses = sum(-x for x in recent if x < 0) / period
    if losses == 0:
        return 100.0 if gains > 0 else 50.0
    rs = gains / losses
    return 100 - (100 / (1 + rs))


def sample_prices() -> list[float]:
    # Clearly labelled synthetic data for UI/demo testing only.
    return [
        1.1000, 1.1002, 1.1001, 1.1004, 1.1003, 1.1006, 1.1008,
        1.1007, 1.1009, 1.1011, 1.1010, 1.1013, 1.1015, 1.1014,
        1.1017, 1.1018, 1.1016, 1.1019, 1.1021, 1.1020, 1.1023,
        1.1025, 1.1024, 1.1027, 1.1028, 1.1026, 1.1029, 1.1031,
        1.1030, 1.1032
    ]


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/health")
def health():
    return jsonify({"ok": True, "service": "SHIBL demo server", "mode": "demo"})


@app.get("/api/status")
def status():
    with STATE_LOCK:
        balance = ACCOUNT["balance"]
        count = len(TRADES)
        profit = sum(t.get("demo_pnl", 0.0) for t in TRADES)
    return jsonify({
        "ok": True,
        "mode": "demo",
        "account": {"balance": round(balance, 2), "currency": "USD"},
        "trades_count": count,
        "profit": round(profit, 2),
        "server_time": utc_now(),
        "real_trading_enabled": False
    })


@app.post("/api/analyze")
def analyze():
    payload = request.get_json(silent=True) or {}
    strategy = str(payload.get("strategy", "ema_crossover")).lower()
    raw_candles = payload.get("candles") or []

    if strategy not in {"ema_crossover", "rsi_reversal"}:
        return jsonify({"ok": False, "error": "الاستراتيجية غير مدعومة"}), 400

    prices: list[float] = []
    if raw_candles:
        if not isinstance(raw_candles, list):
            return jsonify({"ok": False, "error": "صيغة الشموع غير صحيحة"}), 400
        for candle in raw_candles:
            if not isinstance(candle, dict):
                return jsonify({"ok": False, "error": "بيانات الشمعة غير صحيحة"}), 400
            close = as_number(candle.get("close"))
            if close is None or close <= 0:
                return jsonify({"ok": False, "error": "سعر إغلاق غير صالح"}), 400
            prices.append(close)
        data_source = "user_supplied"
    else:
        prices = sample_prices()
        data_source = "synthetic_demo"

    if len(prices) < 15:
        return jsonify({
            "ok": False,
            "error": "يلزم إدخال 15 سعر إغلاق على الأقل",
            "received": len(prices)
        }), 400

    signal = "WAIT"
    details: dict[str, Any] = {}

    if strategy == "ema_crossover":
        fast = ema(prices, 5)
        slow = ema(prices, 12)
        if fast[-1] > slow[-1] and fast[-2] <= slow[-2]:
            signal = "CALL"
        elif fast[-1] < slow[-1] and fast[-2] >= slow[-2]:
            signal = "PUT"
        details = {
            "ema_fast": round(fast[-1], 6),
            "ema_slow": round(slow[-1], 6)
        }
    else:
        value = rsi(prices, 14)
        if value < 30:
            signal = "CALL"
        elif value > 70:
            signal = "PUT"
        details = {"rsi_14": round(value, 2)}

    return jsonify({
        "ok": True,
        "mode": "demo",
        "strategy": strategy,
        "signal": signal,
        "details": details,
        "last_price": prices[-1],
        "data_source": data_source,
        "message": "تحليل تعليمي تجريبي؛ لا تستخدم الإشارة كضمان للربح."
    })


@app.post("/api/demo/order")
def demo_order():
    payload = request.get_json(silent=True) or {}
    direction = str(payload.get("direction", "")).upper()
    amount = as_number(payload.get("amount"))
    duration = payload.get("duration", 1)

    if direction not in {"CALL", "PUT"}:
        return jsonify({"ok": False, "error": "الاتجاه يجب أن يكون CALL أو PUT"}), 400
    if amount is None or amount <= 0 or amount > MAX_TRADE_AMOUNT:
        return jsonify({
            "ok": False,
            "error": f"المبلغ يجب أن يكون أكبر من صفر ولا يتجاوز {MAX_TRADE_AMOUNT:.0f} دولار"
        }), 400
    try:
        duration = int(duration)
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "مدة الصفقة غير صالحة"}), 400
    if duration not in {1, 5, 15}:
        return jsonify({"ok": False, "error": "المدة المدعومة: 1 أو 5 أو 15 دقيقة"}), 400

    with STATE_LOCK:
        if amount > ACCOUNT["balance"]:
            return jsonify({"ok": False, "error": "الرصيد التجريبي غير كافٍ"}), 400

        trade = {
            "id": secrets.token_hex(5),
            "direction": direction,
            "amount": round(amount, 2),
            "duration_minutes": duration,
            "status": "accepted_demo",
            "created_at": utc_now(),
            "demo_pnl": 0.0
        }
        ACCOUNT["balance"] = round(ACCOUNT["balance"] - amount, 2)
        TRADES.append(trade)
        balance = ACCOUNT["balance"]

    return jsonify({
        "ok": True,
        "mode": "demo",
        "trade": trade,
        "account": {"balance": balance, "currency": "USD"},
        "message": "تم تسجيل طلب محاكاة فقط. لم يتم الاتصال بـ Quotex ولم تُنفذ صفقة حقيقية."
    }), 201


@app.get("/api/demo/trades")
def demo_trades():
    with STATE_LOCK:
        return jsonify({"ok": True, "trades": list(reversed(TRADES[-50:]))})


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    app.run(host="0.0.0.0", port=port, debug=False)
