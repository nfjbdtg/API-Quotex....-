# SHIBL
الخطوة الأولى: هيكل مشروع SHIBL الأساسي.

## التشغيل
يتطلب Python 3.10 أو أحدث.

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

افتح `http://127.0.0.1:8000`.

## الوضع الحالي
- واجهة ويب عربية متجاوبة.
- خادم FastAPI.
- قاعدة بيانات SQLite للإعدادات والإشارات.
- وضع تجريبي ومحاكاة فقط؛ لا توجد صفقات حقيقية أو اتصال فعلي بـ Quotex بعد.
