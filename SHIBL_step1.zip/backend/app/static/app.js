const $ = id => document.getElementById(id);
async function api(url, options = {}) {
  const response = await fetch(url, {headers: {"Content-Type": "application/json"}, ...options});
  if (!response.ok) throw new Error(await response.text());
  return response.json();
}
async function refresh() {
  const s = await api("/api/settings");
  ["strategy", "timeframe", "stake", "max_loss"].forEach(k => $(k).value = s[k]);
  $("auto_enabled").checked = !!s.auto_enabled;
  const signals = await api("/api/signals");
  $("signals").innerHTML = signals.length
    ? signals.map(x => `<div class="signal">${x.asset} — ${x.direction} — ${x.timeframe} — ${x.status}</div>`).join("")
    : "لا توجد إشارات بعد.";
}
$("save").onclick = async () => {
  try {
    await api("/api/settings", {method:"PUT", body:JSON.stringify({
      strategy:$("strategy").value, timeframe:$("timeframe").value,
      stake:Number($("stake").value), max_loss:Number($("max_loss").value),
      auto_enabled:$("auto_enabled").checked
    })});
    $("message").textContent = "تم حفظ الإعدادات بنجاح.";
  } catch (e) { $("message").textContent = "تعذر الحفظ: " + e.message; }
};
$("create").onclick = async () => {
  try { await api("/api/signals/demo", {method:"POST"}); await refresh(); }
  catch (e) { $("message").textContent = "تعذر إنشاء الإشارة: " + e.message; }
};
refresh().catch(e => $("message").textContent = "تعذر الاتصال بالخادم: " + e.message);
