from pathlib import Path
import sqlite3
import uuid
from datetime import datetime, timezone

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE = Path(__file__).resolve().parent
DB_PATH = BASE.parent / "shibl.db"

app = FastAPI(title="SHIBL API", version="0.1.0")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


@app.on_event("startup")
def initialize_database():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                strategy TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                stake REAL NOT NULL,
                max_loss REAL NOT NULL,
                auto_enabled INTEGER NOT NULL DEFAULT 0
            )
        """)
        conn.execute("""
            INSERT OR IGNORE INTO settings
            (id, strategy, timeframe, stake, max_loss, auto_enabled)
            VALUES (1, 'trend_pullback', '1m', 1, 10, 0)
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS signals (
                id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                asset TEXT NOT NULL,
                direction TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                status TEXT NOT NULL
            )
        """)


class SettingsInput(BaseModel):
    strategy: str = "trend_pullback"
    timeframe: str = "1m"
    stake: float = Field(default=1, gt=0, le=10000)
    max_loss: float = Field(default=10, gt=0, le=100000)
    auto_enabled: bool = False


@app.get("/", response_class=HTMLResponse)
def home():
    return (BASE / "static" / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "project": "SHIBL",
        "version": "0.1.0",
        "mode": "demo",
        "execution": "simulation_only",
    }


@app.get("/api/settings")
def get_settings():
    with db() as conn:
        row = conn.execute(
            "SELECT strategy, timeframe, stake, max_loss, auto_enabled "
            "FROM settings WHERE id = 1"
        ).fetchone()
    result = dict(row)
    result["auto_enabled"] = bool(result["auto_enabled"])
    return result


@app.put("/api/settings")
def update_settings(settings: SettingsInput):
    if settings.timeframe not in {"1m", "5m", "15m"}:
        return {"saved": False, "error": "Unsupported timeframe"}
    with db() as conn:
        conn.execute(
            """UPDATE settings SET strategy=?, timeframe=?, stake=?,
               max_loss=?, auto_enabled=? WHERE id=1""",
            (
                settings.strategy,
                settings.timeframe,
                settings.stake,
                settings.max_loss,
                int(settings.auto_enabled),
            ),
        )
    return {"saved": True}


@app.post("/api/signals/demo")
def create_demo_signal():
    with db() as conn:
        timeframe = conn.execute(
            "SELECT timeframe FROM settings WHERE id=1"
        ).fetchone()["timeframe"]
        signal = {
            "id": str(uuid.uuid4())[:8],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "asset": "EUR/USD DEMO",
            "direction": "CALL",
            "timeframe": timeframe,
            "status": "SIMULATED",
        }
        conn.execute(
            "INSERT INTO signals VALUES (?, ?, ?, ?, ?, ?)",
            tuple(signal.values()),
        )
    return signal


@app.get("/api/signals")
def list_signals():
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM signals ORDER BY created_at DESC LIMIT 25"
        ).fetchall()
    return [dict(row) for row in rows]
