from pydantic import BaseModel, Field
from typing import Literal
class SettingsUpdate(BaseModel):
    trading_mode: Literal["demo", "paper"] = "demo"
    selected_strategy: str = "manual"
    timeframe: str = "1m"
    max_order_amount: float = Field(default=1, gt=0)
    max_daily_loss: float = Field(default=10, gt=0)
class PaperOrderRequest(BaseModel):
    asset: str = Field(min_length=2, max_length=40)
    direction: Literal["up", "down"]
    amount: float = Field(gt=0)
    expiry_seconds: int = Field(default=60, ge=5, le=3600)
