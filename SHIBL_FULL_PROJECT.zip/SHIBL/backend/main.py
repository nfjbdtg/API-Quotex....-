from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from .config import settings
from .database import init_db,get_settings,save_settings,add_order,orders
from .schemas import SettingsUpdate,PaperOrderRequest
from .strategies import list_strategies
app=FastAPI(title="SHIBL",version="1.0.0")
front=Path(__file__).resolve().parent.parent/"frontend"
app.mount("/static",StaticFiles(directory=front),name="static")
@app.on_event("startup")
def startup(): init_db()
@app.get("/")
def home(): return FileResponse(front/"index.html")
@app.get("/api/health")
def health(): return {"ok":True,"app":"SHIBL","mode":"demo/paper","live_enabled":False}
@app.get("/api/settings")
def read_settings(): return get_settings()
@app.put("/api/settings")
def update_settings(p:SettingsUpdate):
    d=p.model_dump()
    if d["max_order_amount"]>settings.max_order_amount or d["max_daily_loss"]>settings.max_daily_loss:
        raise HTTPException(400,"تجاوزت الحد الأعلى المحدد في إعدادات السيرفر")
    return save_settings(d)
@app.get("/api/strategies")
def strategies(): return list_strategies()
@app.post("/api/paper/order")
def paper_order(p:PaperOrderRequest):
    d=p.model_dump()
    if d["amount"]>min(get_settings()["max_order_amount"],settings.max_order_amount):
        raise HTTPException(400,"مبلغ الصفقة أكبر من الحد المسموح")
    return {"id":add_order(d),"status":"SIMULATED","message":"تم تسجيل صفقة ورقية فقط ولم تُرسل للمنصة"}
@app.get("/api/paper/orders")
def paper_orders(): return orders()
