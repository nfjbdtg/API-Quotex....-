import sqlite3
from pathlib import Path
from .config import settings
def connect():
    Path(settings.database_path).parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(settings.database_path)
    db.row_factory = sqlite3.Row
    return db
def init_db():
    with connect() as db:
        db.execute("CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY CHECK(id=1), trading_mode TEXT DEFAULT 'demo', selected_strategy TEXT DEFAULT 'manual', timeframe TEXT DEFAULT '1m', max_order_amount REAL DEFAULT 1, max_daily_loss REAL DEFAULT 10)")
        db.execute("INSERT OR IGNORE INTO settings (id) VALUES (1)")
        db.execute("CREATE TABLE IF NOT EXISTS paper_orders (id INTEGER PRIMARY KEY AUTOINCREMENT, asset TEXT, direction TEXT, amount REAL, expiry_seconds INTEGER, status TEXT DEFAULT 'SIMULATED', created_at TEXT DEFAULT CURRENT_TIMESTAMP)")
def get_settings():
    with connect() as db:
        return dict(db.execute("SELECT * FROM settings WHERE id=1").fetchone())
def save_settings(d):
    keys = ["trading_mode","selected_strategy","timeframe","max_order_amount","max_daily_loss"]
    vals = {k:d[k] for k in keys if k in d}
    with connect() as db:
        db.execute("UPDATE settings SET "+", ".join(k+"=?" for k in vals)+" WHERE id=1", list(vals.values()))
    return get_settings()
def add_order(o):
    with connect() as db:
        cur = db.execute("INSERT INTO paper_orders(asset,direction,amount,expiry_seconds) VALUES(?,?,?,?)",(o["asset"],o["direction"],o["amount"],o["expiry_seconds"]))
        return cur.lastrowid
def orders():
    with connect() as db:
        return [dict(x) for x in db.execute("SELECT * FROM paper_orders ORDER BY id DESC LIMIT 50").fetchall()]
