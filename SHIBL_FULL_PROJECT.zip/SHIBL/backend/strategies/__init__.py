from importlib import import_module
from pathlib import Path
def list_strategies():
    out=[]
    for p in Path(__file__).parent.glob("*.py"):
        if p.stem.startswith("_") or p.stem=="example_template": continue
        m=import_module("backend.strategies."+p.stem)
        if hasattr(m,"STRATEGY"): out.append(m.STRATEGY)
    return out
