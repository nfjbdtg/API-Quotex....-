# انسخ الملف وغيّر بيانات الاستراتيجية ودالة analyze.
STRATEGY={"id":"my_strategy","name":"My Strategy","description":"اكتب وصفك","enabled":False}
def analyze(candles):
    # candles: open/high/low/close
    return {"signal":"none","reason":"لم تتم برمجتها بعد"}
