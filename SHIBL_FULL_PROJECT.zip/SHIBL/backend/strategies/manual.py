STRATEGY={"id":"manual","name":"Manual","description":"No automatic signals; user decides.","enabled":True}
def analyze(candles):
    return {"signal":"none","reason":"Manual strategy"}
