from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    app_name: str = "SHIBL"
    trading_mode: str = "demo"
    live_trading_enabled: bool = False
    max_order_amount: float = 1.0
    max_daily_loss: float = 10.0
    database_path: str = "data/shibl.db"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")
settings = Settings()
