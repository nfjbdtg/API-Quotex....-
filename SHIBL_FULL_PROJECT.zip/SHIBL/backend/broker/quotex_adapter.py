class QuotexAdapter:
    # Placeholder آمن: لا يوجد تسجيل دخول أو تنفيذ صفقات حقيقية.
    async def connect(self):
        return {"connected":False,"message":"لم يتم إعداد تكامل رسمي موثوق"}
    async def place_order(self, order):
        raise RuntimeError("تنفيذ الصفقات الحقيقية معطّل في هذه النسخة")
