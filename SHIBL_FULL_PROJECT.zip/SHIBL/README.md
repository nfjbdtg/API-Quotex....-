# SHIBL
مشروع جاهز كبداية: واجهة ويب عربية + سيرفر FastAPI + قاعدة SQLite + مكان مستقل لاستراتيجياتك.

## التشغيل
Python 3.11+ ثم:
1. `pip install -r requirements.txt`
2. `uvicorn backend.main:app --host 0.0.0.0 --port 8000`
3. افتح `http://localhost:8000`

أضف استراتيجياتك داخل `backend/strategies/` وعدّل التصميم داخل `frontend/`.
النسخة Demo/Paper فقط. لا تنفذ صفقات حقيقية ولا تسجل الدخول إلى Quotex.
لا توجد API رسمية موثقة مضمّنة؛ ملف broker هو نقطة ربط آمنة فقط. لا تضع كلمات المرور أو ملفات الجلسات في GitHub.
