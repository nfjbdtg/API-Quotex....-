# SHIBL — Demo Trading Platform

SHIBL is a fresh, demo-first trading platform scaffold. This first delivery includes:
- FastAPI backend and health/status endpoints
- Demo-only order simulator (no real-money execution)
- Configurable EMA crossover and RSI strategies
- Lightweight Arabic-friendly web dashboard
- Docker support and basic tests

## Important safety and integration notes
This version does **not** log in to Quotex, collect Quotex passwords, or place live trades. Do not paste account passwords, cookies, session tokens, or API keys into chat or source files. A reliable, authorized Quotex integration must be verified against official platform documentation and terms before it is added. Until then, use the built-in demo simulator only.

## Run locally
Python 3.11+ is recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open:
- Dashboard: http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs
- Health: http://127.0.0.1:8000/api/health

## Run with Docker
```bash
docker compose up --build
```

## Project layout
```text
SHIBL/
├── app/
│   ├── main.py
│   ├── schemas.py
│   ├── strategies.py
│   └── simulator.py
├── static/
│   └── index.html
├── tests/
│   └── test_strategies.py
├── .env.example
├── Dockerfile
├── compose.yaml
└── requirements.txt
```

## Current milestone
Milestone 1: working local foundation + demo simulator. Next milestones can add persistent storage, user authentication, strategy editor, market-data adapter, and then a compliant broker/platform adapter after its interface and permissions are verified.
