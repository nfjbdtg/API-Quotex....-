from dataclasses import dataclass, asdict

@dataclass
class DemoAccount:
    balance: float = 10000.0
    trades: int = 0
    wins: int = 0
    losses: int = 0

    def place_order(self, amount: float, payout_percent: float, result: str) -> dict:
        if amount <= 0 or amount > self.balance:
            raise ValueError("Amount must be positive and cannot exceed demo balance")
        if result == "win":
            profit = amount * payout_percent / 100
            self.balance += profit
            self.wins += 1
        elif result == "loss":
            profit = -amount
            self.balance -= amount
            self.losses += 1
        else:
            raise ValueError("Invalid demo result")
        self.trades += 1
        return {"account": asdict(self), "pnl": round(profit, 2), "mode": "DEMO"}
