from .schemas import Candle, Direction

def _ema(values: list[float], period: int) -> float:
    if len(values) < period:
        raise ValueError(f"At least {period} candles are required")
    alpha = 2 / (period + 1)
    value = sum(values[:period]) / period
    for price in values[period:]:
        value = alpha * price + (1 - alpha) * value
    return value

def _rsi(values: list[float], period: int) -> float:
    if len(values) < period + 1:
        raise ValueError(f"At least {period + 1} candles are required")
    changes = [values[i] - values[i - 1] for i in range(1, len(values))]
    gains = [max(change, 0) for change in changes[-period:]]
    losses = [max(-change, 0) for change in changes[-period:]]
    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period
    if avg_loss == 0:
        return 100.0 if avg_gain > 0 else 50.0
    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def analyze(candles: list[Candle], strategy: str, **params) -> dict:
    closes = [c.close for c in candles]
    if strategy == "ema_crossover":
        fast = int(params.get("fast_period", 9))
        slow = int(params.get("slow_period", 21))
        if fast >= slow:
            raise ValueError("fast_period must be smaller than slow_period")
        if len(closes) < slow:
            raise ValueError(f"At least {slow} candles are required")
        fast_now, slow_now = _ema(closes, fast), _ema(closes, slow)
        fast_prev = _ema(closes[:-1], fast) if len(closes) - 1 >= slow else fast_now
        slow_prev = _ema(closes[:-1], slow) if len(closes) - 1 >= slow else slow_now
        direction: Direction = "CALL" if fast_now > slow_now and fast_prev <= slow_prev else (
            "PUT" if fast_now < slow_now and fast_prev >= slow_prev else "HOLD"
        )
        return {"strategy": strategy, "direction": direction,
                "indicators": {"ema_fast": round(fast_now, 6), "ema_slow": round(slow_now, 6)},
                "note": "Educational signal only; not financial advice."}
    if strategy == "rsi_reversal":
        period = int(params.get("rsi_period", 14))
        oversold = float(params.get("rsi_oversold", 30))
        overbought = float(params.get("rsi_overbought", 70))
        value = _rsi(closes, period)
        direction = "CALL" if value <= oversold else ("PUT" if value >= overbought else "HOLD")
        return {"strategy": strategy, "direction": direction,
                "indicators": {"rsi": round(value, 2)},
                "note": "Educational signal only; not financial advice."}
    raise ValueError("Unknown strategy")
