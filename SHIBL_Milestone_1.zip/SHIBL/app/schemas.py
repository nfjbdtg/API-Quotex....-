from typing import Literal
from pydantic import BaseModel, Field

Direction = Literal["CALL", "PUT", "HOLD"]

class Candle(BaseModel):
    open: float = Field(gt=0)
    high: float = Field(gt=0)
    low: float = Field(gt=0)
    close: float = Field(gt=0)
    volume: float = Field(default=0, ge=0)

class StrategyRequest(BaseModel):
    strategy: Literal["ema_crossover", "rsi_reversal"] = "ema_crossover"
    candles: list[Candle] = Field(min_length=2, max_length=500)
    fast_period: int = Field(default=9, ge=2, le=100)
    slow_period: int = Field(default=21, ge=3, le=200)
    rsi_period: int = Field(default=14, ge=2, le=100)
    rsi_oversold: float = Field(default=30, ge=1, le=49)
    rsi_overbought: float = Field(default=70, ge=51, le=99)

class DemoOrderRequest(BaseModel):
    direction: Literal["CALL", "PUT"]
    amount: float = Field(gt=0, le=1000)
    payout_percent: float = Field(default=80, ge=1, le=100)
    result: Literal["win", "loss"] = "win"
