import os
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from .schemas import StrategyRequest, DemoOrderRequest
from .strategies import analyze
from .simulator import DemoAccount

app = FastAPI(title="SHIBL API", version="0.1.0",
              description="Demo-first trading research platform. Live trading is disabled.")
account = DemoAccount(balance=float(os.getenv("SHIBL_STARTING_BALANCE", "10000")))
STATIC_DIR = Path(__file__).resolve().parent.parent / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return (STATIC_DIR / "index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health():
    return {"status": "ok", "project": "SHIBL", "version": "0.1.0"}

@app.get("/api/status")
def status():
    return {"project": "SHIBL", "mode": "DEMO_ONLY", "live_trading_enabled": False,
            "account": account.__dict__}

@app.post("/api/analyze")
def analyze_market(request: StrategyRequest):
    try:
        params = request.model_dump(exclude={"strategy", "candles"})
        return analyze(request.candles, request.strategy, **params)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

@app.post("/api/demo/order")
def demo_order(request: DemoOrderRequest):
    try:
        return account.place_order(request.amount, request.payout_percent, request.result)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
