import pytest
from app.schemas import Candle
from app.strategies import analyze
from app.simulator import DemoAccount

def candles(values):
    return [Candle(open=v, high=v, low=v, close=v) for v in values]

def test_rsi_returns_hold_for_middle_values():
    data = candles([100 + i * 0.1 for i in range(20)])
    result = analyze(data, "rsi_reversal", rsi_period=14)
    assert result["direction"] == "PUT"  # steady gains produce a high RSI

def test_ema_rejects_invalid_periods():
    with pytest.raises(ValueError):
        analyze(candles([100 + i for i in range(30)]), "ema_crossover",
                fast_period=21, slow_period=9)

def test_demo_loss_reduces_balance():
    account = DemoAccount(1000)
    result = account.place_order(50, 80, "loss")
    assert result["account"]["balance"] == 950
    assert result["mode"] == "DEMO"
